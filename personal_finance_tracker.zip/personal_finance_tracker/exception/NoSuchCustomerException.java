package com.qsp.personal_finance_tracker.exception;

public class NoSuchCustomerException extends RuntimeException{

	public NoSuchCustomerException() {
		// TODO Auto-generated constructor stub
	}
	public NoSuchCustomerException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
