package com.qsp.personal_finance_tracker.exception;

public class UserNotExistException extends RuntimeException{
	
	public UserNotExistException() {
		// TODO Auto-generated constructor stub
	}
	public UserNotExistException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
