package com.qsp.personal_finance_tracker.exception;

public class NegativeAmountException extends RuntimeException{

	public NegativeAmountException() {
		// TODO Auto-generated constructor stub
	}
	public NegativeAmountException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
