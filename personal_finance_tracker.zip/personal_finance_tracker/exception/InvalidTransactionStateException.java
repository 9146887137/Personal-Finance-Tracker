package com.qsp.personal_finance_tracker.exception;

public class InvalidTransactionStateException extends RuntimeException{

	public InvalidTransactionStateException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidTransactionStateException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
