package com.qsp.personal_finance_tracker.exception;

public class AccountCreationException extends RuntimeException{
	
	public AccountCreationException() {
		// TODO Auto-generated constructor stub
	}
	public AccountCreationException(String msg) {
		super(msg);
	}

}
