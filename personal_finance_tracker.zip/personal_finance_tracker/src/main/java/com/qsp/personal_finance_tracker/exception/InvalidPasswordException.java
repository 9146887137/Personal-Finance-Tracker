package com.qsp.personal_finance_tracker.exception;

public class InvalidPasswordException extends RuntimeException{

	public InvalidPasswordException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidPasswordException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
